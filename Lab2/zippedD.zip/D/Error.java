public class Error
{
    static void terminateProgram(String message)
    {
        System.out.println(message);
        System.exit(0);
    }
}
